const assert = require('node:assert/strict');
require('../costing.js');
const C = globalThis.TruckCostCalculations;

const sample = C.calculateJob({revenue:4800,distance:1420,kmPerLitre:2.4,fuelPrice:2.15,tolls:145,driver:620,other:0});
assert.equal(sample.valid, true);
assert.ok(Math.abs(sample.fuel - 1272.0833333333333) < 1e-8);
assert.ok(Math.abs(sample.profit - 2762.916666666667) < 1e-8);
assert.ok(Math.abs(sample.marginPercent - 57.5607638888889) < 1e-8);
assert.ok(Math.abs(sample.profitPerKm - 1.945715962440953) < 1e-8);

for (const bad of [
  {revenue:4800,distance:0,kmPerLitre:2.4,fuelPrice:2.15,tolls:145,driver:620,other:0},
  {revenue:4800,distance:1420,kmPerLitre:0,fuelPrice:2.15,tolls:145,driver:620,other:0},
  {revenue:-1,distance:1420,kmPerLitre:2.4,fuelPrice:2.15,tolls:145,driver:620,other:0},
  {revenue:4800,distance:1420,kmPerLitre:2.4,fuelPrice:2.15,tolls:-1,driver:620,other:0},
  {revenue:'',distance:1420,kmPerLitre:2.4,fuelPrice:2.15,tolls:145,driver:620,other:0},
  {revenue:4800,distance:1420,kmPerLitre:2.4,fuelPrice:2.15,tolls:145,driver:620,other:Infinity}
]) assert.equal(C.calculateJob(bad).valid, false, 'invalid job inputs must be rejected');

assert.equal(C.recordedCostPerKm([{amount:1850}],[{amount:980}],44200), 2830/44200);
assert.equal(C.recordedCostPerKm([{amount:100}],[],0), 0);
assert.equal(C.recordedCostPerKm([{amount:-50},{amount:100}],[],10), 10);
console.log('TruckCost AU costing tests: PASS (sample arithmetic, invalid inputs, recorded cost/km)');


const period = C.calculatePeriodCosts({periodDays:30,kilometres:10000,variableCosts:4500,financeMonthly:2100,insuranceMonthly:420,registrationAnnual:180,permitsAnnual:0,purchasePrice:180000,residualValue:30000,expectedLifeKm:1000000});
assert.equal(period.valid, true);
assert.ok(Math.abs(period.financeCash - 2100*12*30/365) < 1e-8);
assert.ok(Math.abs(period.depreciation - 1500) < 1e-8);
assert.ok(Math.abs(period.cashOutflow - (4500 + 2100*12*30/365 + 420*12*30/365 + 180*30/365)) < 1e-8);
assert.ok(Math.abs(period.economicCost - (4500 + 420*12*30/365 + 180*30/365 + 1500)) < 1e-8);
assert.ok(Math.abs(period.cashCostPerKm - period.cashOutflow/10000) < 1e-12);
assert.ok(Math.abs(period.economicCostPerKm - period.economicCost/10000) < 1e-12);
assert.equal(C.calculatePeriodCosts({periodDays:0,kilometres:10000,variableCosts:4500,financeMonthly:2100,insuranceMonthly:420,registrationAnnual:180,permitsAnnual:0,purchasePrice:180000,residualValue:30000,expectedLifeKm:1000000}).valid, false);
assert.equal(C.calculatePeriodCosts({periodDays:30,kilometres:10000,variableCosts:4500,financeMonthly:2100,insuranceMonthly:420,registrationAnnual:180,permitsAnnual:0,purchasePrice:100000,residualValue:120000,expectedLifeKm:1000000}).valid, false);
console.log('TruckCost AU period accounting tests: PASS (cash vs economic cost, depreciation, overhead allocation, invalid inputs)');
