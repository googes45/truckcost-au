# TruckCost AU — QA candidate v0.8

This package is a corrected demo candidate (v0.8), not a production release.

## What changed in this QA candidate (v0.8)
- Added date-range period reports for a selected truck. Reports summarise saved jobs, job kilometres, revenue, recorded expenses, maintenance and estimated job fuel separately. Reports can be saved locally and are included in backups.
- Reports intentionally do not calculate net profit or combine estimated fuel with recorded costs because those figures can overlap.

## What changed in v0.7
- Replaced the misleading cloud status with **LOCAL DEMO**.
- Standardised truck/dashboard cost per kilometre to recorded expenses and maintenance divided by recorded odometer kilometres. Fixed overheads are deliberately excluded until the app has a consistent reporting period model.
- Separated estimated fuel across saved jobs from recorded expenses so job fuel estimates are not silently added into the same recorded-cost total.
- Added a shared calculation module used by both the job calculator and saved-job display, plus input checks for job, truck, fuel, expense and maintenance forms.
- Backup restore now checks for the expected TruckCost AU collections before replacing current data.
- Receipt capture now clearly says that image selection is not OCR; fields must be entered and checked manually.
- Added a period cost calculator that separates cash outflow (including finance repayments) from economic cost (including depreciation and excluding finance repayments to avoid double counting loan principal). It allocates monthly/annual overheads by days in the entered period and calculates both per-kilometre metrics.
- The job calculator now calls the shared calculation module rather than duplicating the formula in the UI.
- Added automated Node.js tests for job arithmetic, invalid inputs, recorded cost/km, period overhead allocation, depreciation, cash/economic cost separation and invalid period values. Updated the service-worker cache version.

## Publish to GitHub Pages
1. Open `https://github.com/googes45/truckcost-au`.
2. Upload/replace the files in this folder at the repository root: `index.html`, `costing.js`, `manifest.webmanifest`, `sw.js`, `README.md`, and the `icons` folder. Include `tests/` if you want to keep the automated test suite in GitHub.
3. Commit the changes to the branch configured in **Settings → Pages** (usually `main`, root folder).
4. Wait for the Pages deployment to finish. On Android, reload the site; if an older cached version persists, close the installed PWA and reload in Chrome after the service worker cache has updated.

## Demo limitations — do not treat as production
- Demo sign-in is not secure authentication. Never use a real password.
- Data is stored in browser local storage on this device; there is no cloud database or multi-device sync.
- Receipt image is not uploaded or processed by OCR. Receipt fields are manual.
- Cost/km is a **recorded-cost indicator**, not a complete lifetime or period cost. Fixed overheads, depreciation, finance, insurance and registration need a defined period/odometer allocation before a full-cost metric is claimed.
- Backup restore checks the broad data shape but is not a full migration, schema-version or malicious-file security system.

## Automated QA run before publishing
Run `node tests/costing.test.cjs` from this folder. It should print PASS lines for job arithmetic/validation and period-cost accounting.

## QA to run after publishing
- Verify sample job calculation: revenue $4,800; distance 1,420 km; fuel economy 2.4 km/L; fuel price $2.15/L; tolls $145; driver $620; other $0. Expected fuel $1,272.08, estimated profit $2,762.92, margin 57.56%, profit/km $1.95.
- Try zero/negative distance, zero/negative fuel economy, and negative cost values. Invalid jobs must not save.
- Save a job, refresh the page, and confirm it remains visible on the same browser/device.
- Export a backup, then restore it. Try an unrelated JSON file and confirm it is rejected without replacing current data.
- Confirm dashboard cost/km is explicitly labelled as recorded costs and fixed overheads are excluded.
- Open More → Create period report; choose a truck and date range, confirm only in-range records are included, preview and save it, refresh and confirm the saved report remains visible, and export a backup to confirm periodReports is included.
- Open More → Period cost calculator; confirm 30 days, 10,000 km, $4,500 variable costs, $2,100 monthly finance, $420 monthly insurance, $180 annual registration, $0 permits, $180,000 purchase value, $30,000 residual and 1,000,000 km life produces $1,500 estimated depreciation.
- Check cash outflow includes allocated finance; economic cost excludes finance and includes depreciation. Confirm invalid period days and residual value above purchase value are rejected.
