/* TruckCost AU shared, deterministic costing functions. No browser storage or UI dependencies. */
(function (root) {
  'use strict';
  function finiteNumber(value) {
    if (value === '' || value === null || value === undefined) return NaN;
    var n = Number(value);
    return Number.isFinite(n) ? n : NaN;
  }
  function calculateJob(input) {
    var revenue = finiteNumber(input.revenue);
    var distance = finiteNumber(input.distance);
    var kmPerLitre = finiteNumber(input.kmPerLitre);
    var fuelPrice = finiteNumber(input.fuelPrice);
    var tolls = finiteNumber(input.tolls);
    var driver = finiteNumber(input.driver);
    var other = finiteNumber(input.other);
    var values = [revenue, distance, kmPerLitre, fuelPrice, tolls, driver, other];
    if (values.some(function (n) { return !Number.isFinite(n); })) {
      return { valid: false, error: 'All job fields must contain valid numbers.' };
    }
    if (revenue < 0 || fuelPrice < 0 || tolls < 0 || driver < 0 || other < 0) {
      return { valid: false, error: 'Revenue and costs must be non-negative.' };
    }
    if (distance <= 0 || kmPerLitre <= 0) {
      return { valid: false, error: 'Distance and fuel economy must be greater than zero.' };
    }
    var fuel = distance / kmPerLitre * fuelPrice;
    var profit = revenue - fuel - tolls - driver - other;
    return {
      valid: true,
      fuel: fuel,
      totalVariableCost: fuel + tolls + driver + other,
      profit: profit,
      marginPercent: revenue > 0 ? profit / revenue * 100 : null,
      profitPerKm: profit / distance
    };
  }
  function recordedCostPerKm(expenses, maintenance, kilometres) {
    var km = finiteNumber(kilometres);
    if (!Number.isFinite(km) || km <= 0) return 0;
    var total = (expenses || []).concat(maintenance || []).reduce(function (sum, item) {
      var amount = finiteNumber(item && item.amount);
      return sum + (Number.isFinite(amount) && amount >= 0 ? amount : 0);
    }, 0);
    return total / km;
  }
  function calculatePeriodCosts(input) {
    var days = finiteNumber(input.periodDays);
    var km = finiteNumber(input.kilometres);
    var variable = finiteNumber(input.variableCosts);
    var financeMonthly = finiteNumber(input.financeMonthly);
    var insuranceMonthly = finiteNumber(input.insuranceMonthly);
    var registrationAnnual = finiteNumber(input.registrationAnnual);
    var permitsAnnual = finiteNumber(input.permitsAnnual);
    var purchasePrice = finiteNumber(input.purchasePrice);
    var residualValue = finiteNumber(input.residualValue);
    var lifeKm = finiteNumber(input.expectedLifeKm);
    var values = [days, km, variable, financeMonthly, insuranceMonthly, registrationAnnual, permitsAnnual, purchasePrice, residualValue, lifeKm];
    if (values.some(function (n) { return !Number.isFinite(n); })) {
      return { valid: false, error: 'Complete every period-cost field with a valid number.' };
    }
    if (days <= 0 || days > 366 || km <= 0 || lifeKm <= 0) {
      return { valid: false, error: 'Period days must be 1–366; kilometres and expected life kilometres must be greater than zero.' };
    }
    if ([variable, financeMonthly, insuranceMonthly, registrationAnnual, permitsAnnual, purchasePrice, residualValue].some(function (n) { return n < 0; })) {
      return { valid: false, error: 'Costs and asset values must be non-negative.' };
    }
    if (residualValue > purchasePrice) {
      return { valid: false, error: 'Residual value cannot exceed purchase price.' };
    }
    var factor = days / 365;
    var financeCash = financeMonthly * 12 * factor;
    var insurance = insuranceMonthly * 12 * factor;
    var registration = registrationAnnual * factor;
    var permits = permitsAnnual * factor;
    var depreciation = Math.max(0, purchasePrice - residualValue) / lifeKm * km;
    var cashOutflow = variable + financeCash + insurance + registration + permits;
    var economicCost = variable + insurance + registration + permits + depreciation;
    return {
      valid: true,
      financeCash: financeCash,
      insurance: insurance,
      registration: registration,
      permits: permits,
      depreciation: depreciation,
      variableCosts: variable,
      cashOutflow: cashOutflow,
      economicCost: economicCost,
      cashCostPerKm: cashOutflow / km,
      economicCostPerKm: economicCost / km
    };
  }
  root.TruckCostCalculations = {
    calculateJob: calculateJob,
    recordedCostPerKm: recordedCostPerKm,
    calculatePeriodCosts: calculatePeriodCosts
  };
})(typeof window !== 'undefined' ? window : globalThis);
